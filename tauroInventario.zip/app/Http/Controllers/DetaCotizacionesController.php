<?php

namespace App\Http\Controllers;

use App\Models\Deta_Cotizaciones;
use App\Http\Requests\StoreDeta_CotizacionesRequest;
use App\Http\Requests\UpdateDeta_CotizacionesRequest;

class DetaCotizacionesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDeta_CotizacionesRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Deta_Cotizaciones $deta_Cotizaciones)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Deta_Cotizaciones $deta_Cotizaciones)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDeta_CotizacionesRequest $request, Deta_Cotizaciones $deta_Cotizaciones)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Deta_Cotizaciones $deta_Cotizaciones)
    {
        //
    }
}
