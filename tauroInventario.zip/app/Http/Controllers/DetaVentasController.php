<?php

namespace App\Http\Controllers;

use App\Models\Deta_Ventas;
use App\Http\Requests\StoreDeta_VentasRequest;
use App\Http\Requests\UpdateDeta_VentasRequest;

class DetaVentasController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDeta_VentasRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Deta_Ventas $deta_Ventas)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Deta_Ventas $deta_Ventas)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDeta_VentasRequest $request, Deta_Ventas $deta_Ventas)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Deta_Ventas $deta_Ventas)
    {
        //
    }
}
