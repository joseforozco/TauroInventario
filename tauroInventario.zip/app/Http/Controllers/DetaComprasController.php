<?php

namespace App\Http\Controllers;

use App\Models\Deta_Compras;
use App\Http\Requests\StoreDeta_ComprasRequest;
use App\Http\Requests\UpdateDeta_ComprasRequest;

class DetaComprasController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDeta_ComprasRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Deta_Compras $deta_Compras)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Deta_Compras $deta_Compras)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDeta_ComprasRequest $request, Deta_Compras $deta_Compras)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Deta_Compras $deta_Compras)
    {
        //
    }
}
