<?php

namespace App\Http\Controllers;

use App\Models\Medidas;
use App\Http\Requests\StoreMedidasRequest;
use App\Http\Requests\UpdateMedidasRequest;

class MedidasController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreMedidasRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Medidas $medidas)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Medidas $medidas)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateMedidasRequest $request, Medidas $medidas)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Medidas $medidas)
    {
        //
    }
}
