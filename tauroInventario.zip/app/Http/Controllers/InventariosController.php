<?php

namespace App\Http\Controllers;

use App\Models\Inventarios;
use App\Http\Requests\StoreInventariosRequest;
use App\Http\Requests\UpdateInventariosRequest;

class InventariosController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreInventariosRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Inventarios $inventarios)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Inventarios $inventarios)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateInventariosRequest $request, Inventarios $inventarios)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Inventarios $inventarios)
    {
        //
    }
}
