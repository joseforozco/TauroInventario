<?php

namespace App\Filament\Resources\DepartamentosResource\Pages;

use App\Filament\Resources\DepartamentosResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDepartamentos extends CreateRecord
{
    protected static string $resource = DepartamentosResource::class;
}
