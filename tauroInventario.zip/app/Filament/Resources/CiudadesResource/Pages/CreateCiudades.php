<?php

namespace App\Filament\Resources\CiudadesResource\Pages;

use App\Filament\Resources\CiudadesResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCiudades extends CreateRecord
{
    protected static string $resource = CiudadesResource::class;
}
