<?php

namespace App\Filament\Resources\MedidasResource\Pages;

use App\Filament\Resources\MedidasResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMedidas extends CreateRecord
{
    protected static string $resource = MedidasResource::class;
}
