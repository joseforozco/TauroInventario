<?php

namespace App\Filament\Resources\InventariosResource\Pages;

use App\Filament\Resources\InventariosResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInventarios extends CreateRecord
{
    protected static string $resource = InventariosResource::class;
}
