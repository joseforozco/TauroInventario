<?php

namespace App\Filament\Resources\BodegasResource\Pages;

use App\Filament\Resources\BodegasResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBodegas extends CreateRecord
{
    protected static string $resource = BodegasResource::class;
}
