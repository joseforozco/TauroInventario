<?php

namespace App\Filament\Resources;

use Filament\Forms;
use Filament\Tables;
use App\Models\Compras;
use Filament\Forms\Form;
use Filament\Tables\Table;
use App\Models\Inventarios;
use Filament\Resources\Resource;
use Filament\Support\Enums\Alignment;
use Illuminate\Database\Eloquent\Builder;
use App\Filament\Resources\ComprasResource\Pages;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use App\Filament\Resources\ComprasResource\RelationManagers;

class ComprasResource extends Resource
{
    protected static ?string $model = Compras::class;

    protected static ?string $navigationIcon = 'heroicon-o-shopping-cart';
    protected static ?string $navigationGroup= 'Producción';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Datos Factura de Compra')
                    ->schema([
                        Forms\Components\DateTimePicker::make('fecha')
                            ->label('Fecha factura compra')
                            ->default(now())
                            ->date()
                            ->required(),
                        Forms\Components\select::make('proveedores_id')
                            ->label(__('Proveedores'))
                            ->relationship('proveedores','nombre')
                            ->searchable()
                            ->createOptionForm([
                                Forms\Components\TextInput::make('nombre')
                                    ->label(__('ciudades'))
                                    ->placeholder('Digite el nombre de la Ciudad')
                                    ->required(),
                                Forms\Components\select::make('departamentos_id')
                                    ->label(__('Departamento'))
                                    ->relationship('Departamento','nombre')
                                    ->searchable()
                                    ->preload()
                                    ->required()])
                            ->preload(),
                        Forms\Components\TextInput::make('numerofactura')
                            ->label(__('Factura Número'))
                            ->placeholder('Digite el número de factura de compra')
                            ->required()
                            ->Unique()
                            ->maxLength(255)
                        ])->columns(3),
                    Forms\Components\Section::make('Valores Factura de Compra')
                        ->schema([
                            Forms\Components\TextInput::make('valorfactura')
                                ->label(__('Valor Factura'))
                                ->placeholder('Digite el valor de factura de compra')
                                ->required()
                                ->numeric(),
                            Forms\Components\TextInput::make('ivafactura')
                                ->label(__('Valor I.V.A Factura'))
                                ->placeholder('Digite el valor de iva de compra')
                                ->required()
                                ->numeric(),
                            Forms\Components\TextInput::make('totalfactura')
                                ->label(__('Total Factura'))
                                ->placeholder('Total Factura')
                                ->required()
                                ->numeric()
                        ])->columns(3),
                    Forms\Components\Section::make('Valores Factura de Compra')
                        ->schema([
                            Forms\Components\Repeater::make('Items Factura de Compra')
                                ->schema([
                                    Forms\Components\select::make('inventario_id')
                                        ->label('Producto')
                                        ->options(Inventarios::query()->pluck('nombre','id')),
                                    Forms\Components\Textinput::make('cantidad')
                                        ->numeric()
                                        ->default(1)
                                        ->required(),
                                    Forms\Components\Textinput::make('valor')
                                        ->numeric()
                                        ->default(1)
                                        ->required(),
                                    Forms\Components\Textinput::make('subtotal')
                                        ->numeric()
                                        ->required()
                                ])->columns(4)
                        ])->columnSpanFull()

                ]);
    }



    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('fecha')
                    ->date()
                    ->sortable(),
                Tables\Columns\TextColumn::make('proveedores_id')
                    ->numeric()
                    ->sortable(),
                Tables\Columns\TextColumn::make('numerofactura')
                    ->sortable()
                    ->searchable(),
                Tables\Columns\TextColumn::make('valorfactura')
                    ->numeric()
                    ->sortable()
                    ->summarize([
                        Tables\Columns\Summarizers\Sum::make()
                        ->money()
                    ]),
                Tables\Columns\TextColumn::make('ivafactura')
                    ->numeric()
                    ->sortable()
                    ->summarize([
                        Tables\Columns\Summarizers\Sum::make()
                        ->money()
                    ]),
                Tables\Columns\TextColumn::make('totalfactura')
                    ->numeric()
                    ->sortable()
                    ->summarize([
                        Tables\Columns\Summarizers\Sum::make()
                        ->money()
                    ]),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }


    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCompras::route('/'),
            'create' => Pages\CreateCompras::route('/create'),
            'edit' => Pages\EditCompras::route('/{record}/edit'),
        ];
    }
}
