<?php

namespace App\Filament\Resources\CotizacionesResource\Pages;

use App\Filament\Resources\CotizacionesResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCotizaciones extends CreateRecord
{
    protected static string $resource = CotizacionesResource::class;
}
