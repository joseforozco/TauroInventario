<?php
    $brandName = filament()->getBrandName();
?>

<div class="row">
    <div class="col-1">
        <img src="<?php echo e(asset('images/tauro.png')); ?>" alt="" srcset="" class="h-10" />
    </div>

</div>

<!-- <div class="col-1">
    <h1><?php echo $brandName; ?></h1>
  </div>
-->

<?php /**PATH D:\www\tauroInventario\resources\views/vendor/filament-panels/components/logo.blade.php ENDPATH**/ ?>